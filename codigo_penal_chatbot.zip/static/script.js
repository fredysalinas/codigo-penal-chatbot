// Este archivo está vacío por ahora, pero puedes usarlo para agregar animaciones o efectos personalizados
document.addEventListener("DOMContentLoaded", function () {
    console.log("Chat cargado");
});